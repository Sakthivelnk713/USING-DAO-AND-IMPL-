package dao;

import org.project00.entity.Account;


public class AccountDAO {

	 public Account findAccount(String userName );
	    
}
